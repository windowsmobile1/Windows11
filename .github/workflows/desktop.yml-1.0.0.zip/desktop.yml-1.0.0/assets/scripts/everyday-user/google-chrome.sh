#!/bin/bash

if [ ! -f /usr/bin/google-chrome ]; then
    wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
    sudo dpkg -i google-chrome-stable_current_amd64.deb
    rm google-chrome-stable_current_amd64.deb
else
    exit 0
fi